<?php

namespace App\Http\Controllers;

use App\Vote;
use App\Participant;
use App\Candidate;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;

class SearchController extends Controller
{
    function participants(Request $request)
    {
        return Participant::limit(3)->get();
    }
}
