<?php

namespace App\Http\Controllers;

use App\Partner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Participant;

class AnnonceController extends Controller
{

    public function index()
    {
        $pp = Participant::paginate(20);

        $theFake = collect();

        foreach ($pp as $k => $p) {
            $theFake->add([
                'id_post' => 5,
                'titre_post' => 'Developpement algo AI',
                'contenu' => 'Allez! Sautez d joie! Plus de soucis a se faire avec des projets benevolat par enginnova. Vous avez un projet mais pas les fonds necessaires. Enginnova vous aide a former des equipes gratuitemement',
                'slug' => 'SLUG',
                'counts_commentaires' => '23',
                'id_categorie' => '3',
                'type' => 'benovelat',
                'prix' => 'gratuit',
                'created_at' => '2020-01-03 23:04:38',
                'id' => 3,
                'name' => 'romano',
                'etat' => (rand(0, 100) > 20) ? 0 : 1,
                'reponses' => rand(0, 1000),
                'nb_liked' => rand(0, 10000),
                'liked' => (rand(0, 100) > 40) ? 0 : 1,
                'postuled' => (rand(0, 100) > 55) ? 0 : 1,

            ]);
        }

        return $theFake;
    }
}
