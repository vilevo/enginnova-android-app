<?php

namespace App\Http\Controllers;

use App\Partner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Participant;

class PostController extends Controller
{

    public function index()
    {
        $pp = Participant::paginate(20);

        $theFake = collect();

        foreach ($pp as $k => $p) {
            $theFake->add([
                'id_post' => 5,
                'titre_post' => 'Souci avec une fonction Ln',
                'contenu' => 'Je suis un etudiant en terminal D. Nous avons recement fait le cours sur les fonctions ln... mais j\'y arrive pas. Aider moi. SVP',
                'slug' => 'Souci avec une fonction Ln',
                'counts_commentaires' => '23',
                'id_categorie' => '3',
                'created_at' => '2020-01-03 23:04:38',
                'id' => 3,
                'name' => 'romano',
                'avatar' => 'default.png',
                'nb_liked' => rand(0, 10000),
                'liked' => rand(0, 1),
            ]);
        }

        return $theFake;
    }
}
