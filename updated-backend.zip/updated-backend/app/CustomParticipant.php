<?php

namespace App;


class CustomParticipant{

    public $id;
    public $last_name;
    public $first_name;
    public $email;
    public $username;
    public $phone_number;
    public $job;
    public $enterprise;
    public $biography;
    public $quarter;
    public $image;
    public $competencies;
    public $interests;
}