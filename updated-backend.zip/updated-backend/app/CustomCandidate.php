<?php

namespace App;


class CustomCandidate{

    public $id;
    public $name;
    public $subject;
    public $voted;
}